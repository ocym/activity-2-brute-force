<?php
// login.php
session_start();

$servername = "localhost";
$username = "root"; // Default username for XAMPP
$password = ""; // Default password for XAMPP
$dbname = "login_system"; // Name of your database

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // First, fetch the user id for the given username
    $stmt = $conn->prepare("SELECT id, password FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows == 0) {
        echo "Invalid username or password.";
        exit;
    }

    $stmt->bind_result($user_id, $db_password);
    $stmt->fetch();
    $stmt->close();

    // Check if the user has exceeded login attempts within the last 5 minutes
    $stmt = $conn->prepare("SELECT COUNT(*) FROM login_attempts WHERE user_id = ? AND attempt_time > (NOW() - INTERVAL 5 MINUTE)");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($attempts);
    $stmt->fetch();
    $stmt->close();

    if ($attempts >= 5) {
        // User has exceeded login attempts, show the message to try again later
        echo "You have exceeded the maximum number of login attempts. Please try again after 5 minutes.";
        exit;
    }

    // Check if password is correct
    if (password_verify($password, $db_password)) {
        // Login successful
        echo "Login successful!";
        $_SESSION['user_id'] = $user_id;
    } else {
        // Log failed attempt
        $stmt = $conn->prepare("INSERT INTO login_attempts (user_id) VALUES (?)");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $stmt->close();

        // Display message for failed login
        echo "Invalid username or password.";
    }
}

$conn->close();
?>
